function makeCode() {
    var elText = document.getElementById("text");
    var number = parseInt(document.getElementById("numberOfQRCodes").value);
    var qrContainer = document.getElementById("qrcode");
    
    qrContainer.innerHTML = ""; // Clear previous QR codes
    if (!elText.value) {
      alert("Input a text");
      elText.focus();
      return;
    }
    
    for (var i = 0; i < number; i++) {
      var colDiv = document.createElement("div");
      colDiv.className = "col-md-4 qrcode-item";
      
      var newQRCode = document.createElement("div");
      newQRCode.className = "d-flex justify-content-center"; // Center the QR code within the column
      colDiv.appendChild(newQRCode);
      qrContainer.appendChild(colDiv);
      
      new QRCode(newQRCode, {
        text: elText.value,
        width: 160,
        height: 160
      });
    }
  }

  // Event listeners
  document.getElementById("generate").addEventListener("click", makeCode);
  document.getElementById("numberOfQRCodes").addEventListener("keyup", function(e) {
    if (e.key === "Enter") {
      makeCode();
    }
  });
  
  // Initial code generation
  makeCode();