<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class OrdersDataSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'ShopID' => 1,
                'TableID' => 1,
                'OrderStatus' => 'preparing'
            ],
            [
                'ShopID' => 1,
                'TableID' => 2,
                'OrderStatus' => 'completed'
            ]
        ];

        $this->db->table('Orders')->insertBatch($data);
    }
}
