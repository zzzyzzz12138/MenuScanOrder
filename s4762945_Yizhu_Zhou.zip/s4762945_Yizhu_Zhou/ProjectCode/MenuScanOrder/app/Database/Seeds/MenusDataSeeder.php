<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class MenusDataSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
             'ShopID' => 1,
            'Category' => 'Beverage',
            'ItemName' => 'Coffee',
            'MenuDescription' => 'Delicious hot coffee',
            'Price' => 2.99,
            'AvailableQuantity' => 100,
            'ImagePath' => 'path/to/image.jpg'   
            ],
            [
            'ShopID' => 1,
            'Category' => 'Main Course',
            'ItemName' => 'Beef',
            'MenuDescription' => 'Amazing Beef',
            'Price' => 13.99,
            'AvailableQuantity' => 50,
            'ImagePath' => 'path/to/image.jpg'
            ]
            
        ];

        
        $this->db->table('Menus')->insertBatch($data);
    }
}
