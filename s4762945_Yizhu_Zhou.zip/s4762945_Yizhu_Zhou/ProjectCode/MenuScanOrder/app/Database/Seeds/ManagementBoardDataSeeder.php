<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ManagementBoardDataSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'ShopName'        => 'Example Coffee Shop',
            'ShopDescription' => 'A cozy place to enjoy your day with a cup of coffee and pastries.'
        ];

        // insert to Shops table
        $this->db->table('Shops')->insert($data);
    }
}
