<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TablesDataSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'ShopID' => 1,
                'NumberOfSeats' => 4,
                'QRcodeURL' => '/qr_code_path1'
            ],
            [
                'ShopID' => 1,
                'NumberOfSeats' => 4,
                'QRcodeURL' => '/qr_code_path2'
            ],
            [
                'ShopID' => 1,
                'NumberOfSeats' => 4,
                'QRcodeURL' => '/qr_code_path3'
            ]
        ];

        
        $this->db->table('Tables')->insertBatch($data);
    }
}
