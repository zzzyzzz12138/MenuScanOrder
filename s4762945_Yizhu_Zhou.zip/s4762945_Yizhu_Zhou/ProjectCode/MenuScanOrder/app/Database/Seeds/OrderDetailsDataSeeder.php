<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class OrderDetailsDataSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'OrderID' => 3,
                'MenuID' => 1,
                'Quantity' => 3
            ],
            [
                'OrderID' => 3,
                'MenuID' => 2,
                'Quantity' => 2
            ],
            [
                'OrderID' => 4,
                'MenuID' => 4,
                'Quantity' => 1
            ]
        ];

        $this->db->table('OrderDetails')->insertBatch($data);
    }
}
