<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateShopsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'ShopID' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => TRUE,
                'auto_increment' => TRUE
            ],
            'ShopName' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],
            'ShopDescription' => [
                'type' => 'TEXT'
            ]
        ]);

        $this->forge->addKey('ShopID', true);
        $this->forge->createTable('Shops');
    }

    public function down()
    {
        $this->forge->dropTable('Shops');
    }
}
