<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateCustomersTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'UserID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => FALSE
            ]
        ]);

        $this->forge->addKey('UserID', TRUE);
        $this->forge->addForeignKey('UserID', 'Users', 'UserID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('Customers');
    }

    public function down()
    {
        $this->forge->dropTable('Customers', TRUE);
    }
}
