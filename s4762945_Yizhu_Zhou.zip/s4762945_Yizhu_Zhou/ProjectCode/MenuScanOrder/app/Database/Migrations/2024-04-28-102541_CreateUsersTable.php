<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateUsersTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'UserID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'FirstName' => [
                'type' => 'VARCHAR',
                'constraint' => 40
            ],
            'SecondName' => [
                'type' => 'VARCHAR',
                'constraint' => 40
            ],
            'Phone' => [
                'type' => 'VARCHAR',
                'constraint' => 15
            ],
            'Email' => [
                'type' => 'VARCHAR',
                'constraint' => 100
            ],
            'Password' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'UserType' => [
                'type' => 'ENUM',
                'constraint' => ['Staff', 'Customer']
            ]
        ]);

        $this->forge->addKey('UserID', TRUE);
        $this->forge->createTable('Users');
    }

    public function down()
    {
        $this->forge->dropTable('Users', TRUE);
    }
}
