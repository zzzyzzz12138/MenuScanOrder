<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateStaffsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'UserID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => FALSE,
                'unique' => TRUE
            ],
            'ShopID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'Role' => [
                'type' => 'VARCHAR',
                'constraint' => 10
            ],
            'Address' => [
                'type' => 'VARCHAR',
                'constraint' => 100
            ],
            'Salary' => [
                'type' => 'INT',
                'constraint' => 11
            ]
        ]);

        $this->forge->addKey('UserID', TRUE);
        $this->forge->addForeignKey('UserID', 'Users', 'UserID', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('ShopID', 'Shops', 'ShopID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('Staffs');
    }

    public function down()
    {
        $this->forge->dropTable('Staffs', TRUE);
    }
}
