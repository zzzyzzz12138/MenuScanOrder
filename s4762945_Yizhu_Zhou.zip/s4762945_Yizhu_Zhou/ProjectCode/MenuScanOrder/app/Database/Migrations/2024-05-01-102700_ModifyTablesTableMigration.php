<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ModifyTablesTable extends Migration
{
    public function up()
    {
        
        $fields = [
            'QRcodeID' => [
                'name' => 'QRcodeURL',
                'type' => 'TEXT',
                'null' => true,  
            ],
        ];
        $this->forge->modifyColumn('Tables', $fields);
    }

    public function down()
    {
        // Revert the changes
        $fields = [
            'QRcodeURL' => [
                'name' => 'QRcodeID',
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
        ];
        $this->forge->modifyColumn('Tables', $fields);
    }
}
