<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateQRcodesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'QRcodeID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'ShopID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'TableID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'QRcodeURL' => [
                'type' => 'TEXT'
            ]
        ]);

        $this->forge->addKey('QRcodeID', TRUE);
        $this->forge->addForeignKey('ShopID', 'Shops', 'ShopID', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('TableID', 'Tables', 'TableID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('QRcodes');
    }

    public function down()
    {
        $this->forge->dropTable('QRcodes', TRUE);
    }
}
