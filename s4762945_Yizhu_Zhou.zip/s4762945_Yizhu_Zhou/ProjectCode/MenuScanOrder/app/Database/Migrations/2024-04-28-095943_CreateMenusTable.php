<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMenusTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'MenuID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'ShopID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'Category' => [
                'type' => 'VARCHAR',
                'constraint' => 40
            ],
            'ItemName' => [
                'type' => 'VARCHAR',
                'constraint' => 40
            ],
            'MenuDescription' => [
                'type' => 'TEXT'
            ],
            'Price' => [
                'type' => 'DECIMAL',
                'constraint' => '10,2'
            ],
            'AvailableQuantity' => [
                'type' => 'INT',
                'constraint' => 11
            ],
            'ImagePath' => [
                'type' => 'VARCHAR',
                'constraint' => 60
            ]
        ]);

        $this->forge->addKey('MenuID', TRUE);
        $this->forge->addForeignKey('ShopID', 'Shops', 'ShopID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('Menus');
    }

    public function down()
    {
        $this->forge->dropTable('Menus', TRUE);
    }
}
