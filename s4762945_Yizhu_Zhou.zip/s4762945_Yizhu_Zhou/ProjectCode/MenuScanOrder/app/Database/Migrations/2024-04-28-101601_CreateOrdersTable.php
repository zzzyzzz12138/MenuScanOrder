<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateOrdersTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'OrderID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'ShopID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'TableID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'OrderStatus' => [
                'type' => 'ENUM',
                'constraint' => ['completed', 'preparing'],
                'default' => 'preparing'
            ],
            'TimeStamp' => [
                'type' => 'TIMESTAMP'
            ]
        ]);

        $this->forge->addKey('OrderID', TRUE);
        $this->forge->addForeignKey('ShopID', 'Shops', 'ShopID', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('TableID', 'Tables', 'TableID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('Orders');
    }

    public function down()
    {
        $this->forge->dropTable('Orders', TRUE);
    }
}
