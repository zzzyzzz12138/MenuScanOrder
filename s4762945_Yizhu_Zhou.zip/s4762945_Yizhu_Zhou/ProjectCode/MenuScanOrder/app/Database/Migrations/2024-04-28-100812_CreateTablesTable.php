<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTablesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'TableID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'ShopID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ],
            'NumberOfSeats' => [
                'type' => 'INT',
                'constraint' => 11
            ],
            'QRcodeID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE
            ]
        ]);

        $this->forge->addKey('TableID', TRUE);
        $this->forge->addForeignKey('ShopID', 'Shops', 'ShopID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('Tables');
    }

    public function down()
    {
        $this->forge->dropTable('Tables', TRUE);
    }
}
