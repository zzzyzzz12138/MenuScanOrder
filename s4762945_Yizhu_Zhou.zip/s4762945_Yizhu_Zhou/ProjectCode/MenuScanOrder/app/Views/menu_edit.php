<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Edit Menu Information</h2>
                    <form method="post" action="<?= site_url('ManagementBoard/update_menus/' . $menu['MenuID']); ?>">
                        <div class="mb-3">
                            <label for="ShopID" class="form-label">Shop ID:</label>
                            <input type="text" class="form-control" id="ShopID" name="ShopID" value="<?= esc($menu['ShopID']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="Category" class="form-label">Category:</label>
                            <select class="form-control" id="Category" name="Category" required>
                                <option value="Main Course" <?= $menu['Category'] == 'Main Course' ? 'selected' : ''; ?>>Main Course</option>
                                <option value="Beverages" <?= $menu['Category'] == 'Beverages' ? 'selected' : ''; ?>>Beverages</option>
                                <option value="Snacks" <?= $menu['Category'] == 'Snacks' ? 'selected' : ''; ?>>Snacks</option>
                                <option value="Dessert" <?= $menu['Category'] == 'Dessert' ? 'selected' : ''; ?>>Dessert</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="ItemName" class="form-label">Item Name:</label>
                            <input type="text" class="form-control" id="ItemName" name="ItemName" value="<?= esc($menu['ItemName']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="MenuDescription" class="form-label">Description:</label>
                            <textarea class="form-control" id="MenuDescription" name="MenuDescription" required><?= esc($menu['MenuDescription']); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="Price" class="form-label">Price:</label>
                            <input type="text" class="form-control" id="Price" name="Price" value="<?= esc($menu['Price']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="AvailableQuantity" class="form-label">Available Quantity:</label>
                            <input type="number" class="form-control" id="AvailableQuantity" name="AvailableQuantity" value="<?= esc($menu['AvailableQuantity']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="ImagePath" class="form-label">Image Path:</label>
                            <input type="text" class="form-control" id="ImagePath" name="ImagePath" value="<?= esc($menu['ImagePath']); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
