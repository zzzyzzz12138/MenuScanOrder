<nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <a class="navbar-brand" >Navbar - Welcome</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="true" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse show" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?= site_url('/QRcodeGeneration'); ?>">QR code generation</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?= site_url('/ManagementBoard'); ?>">Admin_management</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?= site_url('/login'); ?>">Login</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>