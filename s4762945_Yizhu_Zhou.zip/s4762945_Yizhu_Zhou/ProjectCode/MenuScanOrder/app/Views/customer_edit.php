<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Edit Customer Information</h2>
                    <form method="post" action="<?= site_url('ManagementBoard/update_customer/' . $customer['UserID']); ?>">
                        <div class="mb-3">
                            <label for="FirstName" class="form-label">First Name:</label>
                            <input type="text" class="form-control" id="FirstName" name="FirstName" value="<?= esc($customer['FirstName']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="SecondName" class="form-label">Second Name:</label>
                            <input type="text" class="form-control" id="SecondName" name="SecondName" value="<?= esc($customer['SecondName']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="Phone" class="form-label">Phone:</label>
                            <input type="tel" class="form-control" id="Phone" name="Phone" value="<?= esc($customer['Phone']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="Email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="Email" name="Email" value="<?= esc($customer['Email']); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
