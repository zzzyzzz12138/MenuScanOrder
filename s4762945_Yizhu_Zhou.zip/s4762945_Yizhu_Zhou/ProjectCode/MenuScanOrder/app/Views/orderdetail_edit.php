<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order Detail Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Edit Order Detail Information</h2>
                    <form method="post" action="<?= site_url('ManagementBoard/update_orderdetail/' . $orderDetail['OrderDetailID']); ?>">
                        <div class="mb-3">
                            <label for="OrderID" class="form-label">Order ID:</label>
                            <input type="number" class="form-control" id="OrderID" name="OrderID" value="<?= esc($orderDetail['OrderID']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="MenuID" class="form-label">Menu ID:</label>
                            <input type="number" class="form-control" id="MenuID" name="MenuID" value="<?= esc($orderDetail['MenuID']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="Quantity" class="form-label">Quantity:</label>
                            <input type="number" class="form-control" id="Quantity" name="Quantity" value="<?= esc($orderDetail['Quantity']); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
