<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Edit Order Information</h2>
                    <form method="post" action="<?= site_url('ManagementBoard/update_order/' . $order['OrderID']); ?>">
                        <div class="mb-3">
                            <label for="ShopID" class="form-label">Shop ID:</label>
                            <input type="number" class="form-control" id="ShopID" name="ShopID" value="<?= esc($order['ShopID']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="TableID" class="form-label">Table ID:</label>
                            <input type="number" class="form-control" id="TableID" name="TableID" value="<?= esc($order['TableID']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="OrderStatus" class="form-label">Order Status:</label>
                            <select class="form-control" id="OrderStatus" name="OrderStatus" required>
                                <option value="preparing" <?= $order['OrderStatus'] == 'preparing' ? 'selected' : ''; ?>>Preparing</option>
                                <option value="completed" <?= $order['OrderStatus'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
