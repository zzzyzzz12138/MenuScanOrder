<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR code generation</title>

    <script src="https://cdn.jsdelivr.net/npm/qrcode-generator/qrcode.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css'); ?>"> 
</head>
<body>
    

    <div class="content">

    <!-- navbar -->
    <?= view('navbar_template'); ?>

    <div class="QR_Tables">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Tables</h1>
        <a href="<?= site_url('QRcodeGeneration/add'); ?>" class="btn btn-success">Add New Table</a>
      </div>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ShopID</th>
                <th scope="col">TableID</th>
                <th scope="col">NumberOfSeats</th>
                <th scope="col">QR_code</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tables as $table): ?>
            <tr>
                <td><?= esc($table['ShopID']); ?></td>
                <td><?= esc($table['TableID']); ?></td>
                <td><?= esc($table['NumberOfSeats']); ?></td>
                <td><?= esc($table['QRcodeURL']); ?></td>
                <td>
                    <a href="<?= site_url('QRcodeGeneration/edit/' . $table['TableID']); ?>" class="btn btn-primary btn-sm">Edit</a>
                    <a href="<?= site_url('QRcodeGeneration/delete/' . $table['TableID']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this table?');">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>


        <form id="qr-form">
            <input type="text" id="shopId" placeholder="Enter Shop ID" required>
            <input type="text" id="tableId" placeholder="Enter Table ID" required>
            <button type="submit" class="btn btn-primary">Generate QR Code</button>
        </form>
        <div id="qrcode-display"></div>
        <p>Don't forget to record the generated QR code along with its corresponding Shop ID and Table ID to avoid confusion.</p>


    </div>

    <!-- Footer -->
    <?= view('footer_template'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs/qrcode.min.js"></script>
<script>
    document.getElementById('qr-form').addEventListener('submit', function(event) {
    event.preventDefault();

    var shopId = document.getElementById('shopId').value;
    var tableId = document.getElementById('tableId').value;
    var baseUrl = 'https://infs3202-366c6859.uqcloud.net/MenuScanOrder/index.php/view_menus'; // base URL

    var fullUrl = `${baseUrl}?shop_id=${shopId}&table_id=${tableId}`;

    var qr = qrcode(0, 'L');
    qr.addData(fullUrl);
    qr.make();

    var qrcodeDisplay = document.getElementById('qrcode-display');
    qrcodeDisplay.innerHTML = ''; 
    var imgTag = document.createElement('img');
    imgTag.src = qr.createDataURL();
    qrcodeDisplay.appendChild(imgTag);
});

</script>
</body>
</html>
