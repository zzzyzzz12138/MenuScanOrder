<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin_management</title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css'); ?>">  
    
  </head>
  <body>
    <div class="content">

    <!-- navbar -->
    <?= view('navbar_template'); ?>

        <div id="management-board">
              
            <div class="Shop Description">
              <h1>Information</h1>
              <table class="table">
                  <thead>
                      <tr>
                          <th scope="col">Shop ID</th>
                          <th scope="col">Shop Name</th>
                          <th scope="col">Shop Description</th>
                          <th scope="col">Actions</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($shops as $shop): ?>
                      <tr>
                          <td><?= esc($shop['ShopID']); ?></td>
                          <td><?= esc($shop['ShopName']); ?></td>
                          <td><?= esc($shop['ShopDescription']); ?></td>
                          <td>
                              <!-- Assuming you have a route and method for editing shops -->
                              <a href="<?= site_url('ManagementBoard/edit/' . $shop['ShopID']); ?>" class="btn btn-primary btn-sm">Edit</a>
                          </td>
                      </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
                
        <div class="Menus">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h1>Current Menus</h1>
                <div>
                    <input type="number" placeholder="Enter your ShopID" id="shopIDInput">
                    <button onclick="viewMenus()" class="btn btn-primary">View the Menus</button>
                </div>
                <a href="<?= site_url('/menu_add'); ?>" class="btn btn-success">Add New Menu</a>
            </div>

          <table class="table">
              <thead>
                <tr>
                  <th scope="col">ShopID</th>
                  <th scope="col">MenuID</th>
                  <th scope="col">Category</th>
                  <th scope="col">ItemName</th>
                  <th scope="col">Description</th>
                  <th scope="col">Price</th>
                  <th scope="col">AvailableQuantity</th>
                  <th scope="col">ImagePath</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                  <?php foreach ($menus as $menu): ?>
                  <tr>
                      <td><?= esc($menu['ShopID']); ?></td>
                      <td><?= esc($menu['MenuID']); ?></td>
                      <td><?= esc($menu['Category']); ?></td>
                      <td><?= esc($menu['ItemName']); ?></td>
                      <td><?= esc($menu['MenuDescription']); ?></td>
                      <td><?= esc($menu['Price']); ?></td>
                      <td><?= esc($menu['AvailableQuantity']); ?></td>
                      <td><?= esc($menu['ImagePath']); ?></td>
                      <td>
                          <a href="<?= site_url('ManagementBoard/edit_menus/' . $menu['MenuID']); ?>" class="btn btn-primary">Edit</a>
                          <a href="<?= site_url('ManagementBoard/delete_menus/' . $menu['MenuID']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                      </td>
                  </tr>
                  <?php endforeach; ?>
              </tbody>
            </table>
    </div>


            <div class="Orders">
            <h1>Orders</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">ShopID</th>
                        <th scope="col">OrderID</th>
                        <th scope="col">TableID</th>
                        <th scope="col">OrderStatus</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= esc($order['ShopID']); ?></td>
                        <td><?= esc($order['OrderID']); ?></td>
                        <td><?= esc($order['TableID']); ?></td>
                        <td class="status"><?= esc($order['OrderStatus']); ?></td>
                        <td>
                          <a href="<?= site_url('ManagementBoard/edit_order/' . $order['OrderID']); ?>" class="btn btn-primary">Edit</a>
                          <a href="<?= site_url('ManagementBoard/delete_order/' . $order['OrderID']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>


        <div class="OrderDetails">
        <h1 class="mt-5">OrderDetails</h1>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">OrderDetailID</th>
                    <th scope="col">OrderID</th>
                    <th scope="col">MenuID</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderDetails as $detail): ?>
                <tr>
                    <th scope="row"><?= esc($detail['OrderDetailID']); ?></th>
                    <td><?= esc($detail['OrderID']); ?></td>
                    <td><?= esc($detail['MenuID']); ?></td>
                    <td><?= esc($detail['Quantity']); ?></td>
                    <td>
                          <a href="<?= site_url('ManagementBoard/edit_orderdetail/' . $detail['OrderDetailID']); ?>" class="btn btn-primary">Edit</a>
                          <a href="<?= site_url('ManagementBoard/delete_orderdetail/' . $detail['OrderDetailID']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

                <div class="Staff">
                  <h1>Staffs</h1>
                  <table class="table">
                      <thead>
                          <tr>
                              <th scope="col">UserID</th>
                              <th scope="col">ShopID</th>
                              <th scope="col">FirstName</th>
                              <th scope="col">SecondName</th>
                              <th scope="col">Phone</th>
                              <th scope="col">Email</th>
                              <th scope="col">Role</th>
                              <th scope="col">Address</th>
                              <th scope="col">Salary</th>
                              <th scope="col">Actions</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php foreach ($staff as $s): ?>
                          <tr>
                              <th scope="row"><?= esc($s['UserID']); ?></th>
                              <td><?= esc($s['ShopID']); ?></td>
                              <td><?= esc($s['FirstName']); ?></td>
                              <td><?= esc($s['SecondName']); ?></td>
                              <td><?= esc($s['Phone']); ?></td>
                              <td><?= esc($s['Email']); ?></td>
                              <td><?= esc($s['Role']); ?></td>
                              <td><?= esc($s['Address']); ?></td>
                              <td><?= esc($s['Salary']); ?></td>
                              <td>
                                  <a href="<?= site_url('ManagementBoard/edit_staff/' . $s['UserID']); ?>" class="btn btn-primary">Edit</a>
                                  <a href="<?= site_url('ManagementBoard/delete_staff/' . $s['UserID']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                              </td>
                          </tr>
                          <?php endforeach; ?>
                      </tbody>
                  </table>
              </div>


              <div class="Customer">
                <h1>Customers</h1>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">UserID</th>
                            <th scope="col">FirstName</th>
                            <th scope="col">SecondName</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Email</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?= esc($customer['UserID']); ?></td>
                            <td><?= esc($customer['FirstName']); ?></td>
                            <td><?= esc($customer['SecondName']); ?></td>
                            <td><?= esc($customer['Phone']); ?></td>
                            <td><?= esc($customer['Email']); ?></td>
                            <td>
                                <a href="<?= site_url('ManagementBoard/edit_customer/' . $customer['UserID']); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?= site_url('ManagementBoard/delete_customer/' . $customer['UserID']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            </div>

    </div>
    
        <!-- Footer -->
        <?= view('footer_template'); ?>
         
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
   <script>
        document.addEventListener('DOMContentLoaded', function() {
            var statuses = document.querySelectorAll('.status');
            statuses.forEach(function(status) {
                if (status.textContent.trim() === 'preparing') {
                    status.style.color = 'red';
                }
            });
        });
    </script>
    <script>
    function viewMenus() {
        var shopId = document.getElementById('shopIDInput').value;
        if (shopId) {
            window.location.href = '<?= site_url('/view_menus?shop_id=') ?>' + shopId;
        } else {
            alert('Please enter a Shop ID');
        }
    }
</script>
  </body>
</html>