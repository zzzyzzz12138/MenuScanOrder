<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tokyo Grand Restaurant</title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('css/lbt.css'); ?>">   
    <style>
        .background_image {
            background-image: url("<?= base_url('images/background.jpeg'); ?>");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            width: 100%;
            height: 70vh;
            z-index: -3;
        }
</style>

  </head>
  <body>
    <div class="content">

    <!-- navbar -->
    <?= view('navbar_template'); ?>

      <section class="background_image">    
      </section>

      <section class="home" id="home">
        <div class="container">         
              <div class="col-md-6">
                 <img src="<?= base_url('images/staffs.png'); ?>" alt="staffs">
              </div>
              <div class="col-md-6 text-center text-md-left">
                 <span><?= (isset($shopName) && !empty($shopName)) ? esc($shopName) : 'Default Shop Name'; ?></span>
                 <h3>Welcome to our restaurant, served by the famous Tokyo Grand Restaurant.</h3>
              </div>
        </div>
        
        <!-- Restaurant introdection -->
        <section class="about" id="about">
            <div class="container">
                <div class="row align-items-center">
                    
                    <div class="col-md-6">
                        <span>About Restaurant</span>
                        <h3><?= (isset($shopName) && !empty($shopName)) ? esc($shopName) : 'Default Shop Name'; ?></h3>
                        <p><?= (isset($shopDescription) && !empty($shopDescription)) ? esc($shopDescription) : 'No description available.'; ?></p>


                        <ul>
                            <li> <i class="far fa-check-square"></i> Superior Location </li>
                            <li> <i class="far fa-check-square"></i> Exquisite Accommodations</li>
                            <li> <i class="far fa-check-square"></i> Culinary Experience</li>
                            <li> <i class="far fa-check-square"></i> First-Class Service</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <img src="<?= base_url('images/restaurant_1.png'); ?>" alt="restaurant photo_1">
                        <img src="<?= base_url('images/restaurant_2.png'); ?>" alt="restaurant photo_2">
                    </div>
            </div>
        </section>
        
        <!-- Main courses -->
        <img src="<?= base_url('/images/Main_coureses_couver.png'); ?>" alt="Main_coureses_couver">
        <div class="Beverages_heading" style="display: flex; justify-content: center; align-items: center;">
            <h1>Main courses</h1>
        </div>
        <?php if (isset($mainCourses) && !empty($mainCourses)): ?>
        <section class="courses" id="courses">
            <div class="box-container container">
                <?php foreach ($mainCourses as $course): ?>
                <div class="box">
                    <div class="image">
                        <img src="<?= base_url('' . esc($course['ImagePath'])); ?>" alt="<?= esc($course['ItemName']); ?>">
                    </div>
                    <div class="content">
                        <p>
                            <span class="dish-name"><?= esc($course['ItemName']); ?></span> - 
                            <span class="dish-description"><?= esc($course['MenuDescription']); ?></span>
                            <span class="dish-price">Price: <?= esc($course['Price']); ?>€</span>
                        </p>
                        <button type="button" class="btn btn-primary btn-lg btn-order" data-menu-id="<?= esc($course['MenuID']); ?>"
                            data-item-name="<?= esc($course['ItemName']); ?>"
                            data-price="<?= esc($course['Price']); ?>" data-description="<?= esc($course['MenuDescription']); ?>"
                            data-image="<?= base_url('' . esc($course['ImagePath'])); ?>"
                            style="position: relative; z-index: 1000;">
                            Order
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php else: ?>
        <p>No main courses available. Please go to the management board to add some menu!</p>
        <?php endif; ?>



        <!-- Beverages -->
         <div class="Beverages_heading" style="display: flex; justify-content: center; align-items: center;">
            <h1>Beverages</h1>
        </div>
        <?php if (isset($beverages) && !empty($beverages)): ?>
        <section class="courses" id="courses">
            <div class="box-container container">
                <?php foreach ($beverages as $beverage): ?>
                <div class="box">
                    <div class="image">
                        <img src="<?= base_url('' . esc($beverage['ImagePath'])); ?>" alt="<?= esc($beverage['ItemName']); ?>">
                    </div>
                    <div class="content">
                        <p>
                            <span class="dish-name"><?= esc($beverage['ItemName']); ?></span> - 
                            <span class="dish-description"><?= esc($beverage['MenuDescription']); ?></span>
                            <span class="dish-price">Price: <?= esc($beverage['Price']); ?>€</span>
                        </p>
                        <!-- <button type="button" class="btn btn-primary btn-lg">Order</button> -->
                        <button type="button" class="btn btn-primary btn-lg btn-order" data-menu-id="<?= esc($beverage['MenuID']); ?>"
                            data-item-name="<?= esc($beverage['ItemName']); ?>"
                            data-price="<?= esc($beverage['Price']); ?>" data-description="<?= esc($beverage['MenuDescription']); ?>"
                            data-image="<?= base_url('' . esc($beverage['ImagePath'])); ?>"
                            style="position: relative; z-index: 1000;">
                            Order
                        </button>    
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php else: ?>
        <p>No beverages available. Please go to the management board to add some menu!</p>
        <?php endif; ?>


    </div>

        <button class="floating-button btn btn-primary" data-bs-toggle="modal" data-bs-target="#orderModal">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-bag-check-fill" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0m-.646 5.354a.5.5 0 0 0-.708-.708L7.5 10.793 6.354 9.646a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0z"/>
            </svg>
            <span>View your orderdetails</span>
        </button>

        <!-- Modal -->
        <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="orderModalLabel">Selected dishes</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- dishes will display here -->
                        <div id="order-items-list"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="submit-order-btn" class="btn btn-primary">Submit Order</button>
                    </div>

                </div>
            </div>
        </div>



        
        <!-- Footer -->
        <?= view('footer_template'); ?>
        
        
   <script src="<?= base_url('js/lbt.js'); ?>"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
   <script> // This is generated by ChatGPT
        document.addEventListener('DOMContentLoaded', function () {
    var orderButtons = document.querySelectorAll('.btn-order');
    var orderItemsList = document.getElementById('order-items-list');

    // Function to add order items to the modal
    function addOrderItem(menuID, itemName, price, description, image) {
        const itemHtml = `
            <div class="order-item" data-menu-id="${menuID}">
                <img src="${image}" alt="${itemName}" style="width: 50px; height: 50px;">
                <span>${itemName} - ${description} - ${price}€</span>
                <input type="number" value="1" min="1" class="form-control quantity" style="width: 60px; display: inline-block; margin-left: 10px;">
                <button class="btn btn-danger btn-sm remove-item">Remove</button>
            </div>
        `;
        orderItemsList.innerHTML += itemHtml;
    }

    // Event listener for order buttons
    orderButtons.forEach(button => {
        button.addEventListener('click', function () {
            var menuID = this.getAttribute('data-menu-id');
            var itemName = this.getAttribute('data-item-name');
            var price = this.getAttribute('data-price');
            var description = this.getAttribute('data-description');
            var image = this.getAttribute('data-image');
            addOrderItem(menuID, itemName, price, description, image);
            $('#orderModal').modal('show');
        });
    });

    // Remove items from the modal
    orderItemsList.addEventListener('click', function (e) {
        if (e.target.classList.contains('remove-item')) {
            e.target.parentNode.remove();
        }
    });

    // Function to handle order submission
    document.getElementById('submit-order-btn').addEventListener('click', function () {
        const tableId = document.getElementById('tableId').value; // Assuming you have a way to input this
        const orders = [];
        document.querySelectorAll('.order-item').forEach(item => {
            const menuID = item.getAttribute('data-menu-id');
            const quantity = item.querySelector('.quantity').value;
            orders.push({menuID, quantity});
        });

        fetch('/submit-order', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({orders, tableId})
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('Order submitted successfully!');
                $('#orderModal').modal('hide');
            }
        })
        .catch(error => {
            console.error('Error submitting order:', error);
            alert('Failed to submit order.');
        });
    });
});


   </script>
  </body>
</html>