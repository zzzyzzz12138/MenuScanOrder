<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Shop Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Edit Shop Information</h2>
                    <form method="post" action="<?= site_url('ManagementBoard/update/' . $shop['ShopID']); ?>">
                        <div class="mb-3">
                            <label for="ShopName" class="form-label">Shop Name:</label>
                            <input type="text" class="form-control" id="ShopName" name="ShopName" value="<?= esc($shop['ShopName']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="ShopDescription" class="form-label">Shop Description:</label>
                            <textarea class="form-control" id="ShopDescription" name="ShopDescription" required><?= esc($shop['ShopDescription']); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
