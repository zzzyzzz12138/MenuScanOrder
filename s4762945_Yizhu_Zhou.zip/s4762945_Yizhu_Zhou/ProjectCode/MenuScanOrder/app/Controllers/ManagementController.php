<?php

namespace App\Controllers;

use App\Models\ShopInformationModel;
use App\Models\MenusModel;
use App\Models\UserModel;
use App\Models\OrdersModel;
use App\Models\OrderDetailsModel;

class ManagementController extends BaseController
{
    
    public function index()
    {
        //display all the database information 
        $model = new ShopInformationModel();
        $data['shops'] = $model->findAll();

        $menuModel = new MenusModel();
        $data['menus'] = $menuModel->findAll();

        $model = new UserModel();
        $data['staff'] = $model->getAllStaffDetails();

        $model = new UserModel();
        $data['customers'] = $model->getAllCustomerDetails();

        $model = new OrdersModel();
        $data['orders'] = $model->getAllOrders();

        $model = new OrderDetailsModel();
        $data['orderDetails'] = $model->getAllOrderDetails();

        return view('ManagementBoard', $data);

        
    }

    //Information table:
    public function edit($shopId)
    {
        $model = new ShopInformationModel();
        $shop = $model->find($shopId); // get the shopid

        return view('shop_edit', ['shop' => $shop]);
    }
    public function update($shopId)
    {
        $model = new ShopInformationModel();
        $data = [
            'ShopName' => $this->request->getPost('ShopName'),
            'ShopDescription' => $this->request->getPost('ShopDescription'),
        ];

        if ($model->update($shopId, $data)) {
            // success to update
            return redirect()->to('/ManagementBoard')->with('message', 'Shop updated successfully');
        } else {
            // fail to update
            return redirect()->back()->with('error', 'Failed to update shop');
        }
    }

    //Menus table:
    public function edit_menus($menuId)
    {
        $model = new MenusModel();
        $data['menu'] = $model->find($menuId);

        return view('menu_edit', $data);
    }
    public function update_menus($menuId)
    {
        $model = new MenusModel();
        $data = [
            'Category' => $this->request->getPost('Category'),
            'ItemName' => $this->request->getPost('ItemName'),
            'MenuDescription' => $this->request->getPost('MenuDescription'),
            'Price' => $this->request->getPost('Price'),
            'AvailableQuantity' => $this->request->getPost('AvailableQuantity'),
            'ImagePath' => $this->request->getPost('ImagePath')
        ];

        if ($model->update($menuId, $data)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Menu updated successfully');
        } else {
            return redirect()->back()->with('errors', $model->errors());
        }
    }
    public function delete_menus($menuId)
    {
        $model = new MenusModel();

        if ($model->delete($menuId)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Menu deleted successfully');
        } else {
            return redirect()->back()->with('message', 'Failed to delete the menu');
        }
    }
    public function menu_add()
    {
        return view('menu_add'); 
    }
    public function create_menus()
    {
        $model = new MenusModel();

        $data = [
            'ShopID' => $this->request->getPost('ShopID'),
            'Category' => $this->request->getPost('Category'),
            'ItemName' => $this->request->getPost('ItemName'),
            'MenuDescription' => $this->request->getPost('MenuDescription'),
            'Price' => $this->request->getPost('Price'),
            'AvailableQuantity' => $this->request->getPost('AvailableQuantity'),
            'ImagePath' => $this->request->getPost('ImagePath')
        ];

        if ($model->insert($data)) {
            return redirect()->to('/ManagementBoard')->with('message', 'New menu added successfully');
        } else {
            return redirect()->back()->with('errors', $model->errors())->with('message', 'Failed to add new menu');
        }
    }

    //staff table
    public function edit_staff($userID)
    {
        $model = new UserModel();
        //$data['staff'] = $model->find($userID);
        //$data['staff'] = $model->find($userId);
        $staff = $model->getStaffDetails($userID);

        if (!$staff) {
            session()->setFlashdata('error', "No staff found with ID $userID");
            return redirect()->to('/ManagementBoard');
        }

        return view('staff_edit', ['staff' => $staff]);
        //return view('staff_edit', $data);
    }
    public function update_staff($userID)
    {
        $model = new UserModel();

        $userData = [
            'FirstName' => $this->request->getPost('FirstName'),
            'SecondName' => $this->request->getPost('SecondName'),
            'Phone' => $this->request->getPost('Phone'),
            'Email' => $this->request->getPost('Email'),
        ];

        $staffData = [
            'ShopID' => $this->request->getPost('ShopID'),
            'Role' => $this->request->getPost('Role'),
            'Address' => $this->request->getPost('Address'),
            'Salary' => $this->request->getPost('Salary'),
        ];

        if ($model->updateStaff($userID, $userData, $staffData)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Staff updated successfully');
        } else {
            return redirect()->back()->with('error', 'Failed to update staff');
        }
    }
    public function delete_staff($userID)
    {
        $model = new UserModel();
        
        if ($model->delete($userID)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Staff deleted successfully');
        } else {
            return redirect()->back()->with('error', 'Failed to delete staff');
        }
    }

    // customer table
    public function edit_customer($userID)
    {
        $model = new UserModel();
        $customer = $model->getCustomerDetails($userID);

        if (!$customer) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Customer with ID ' . $userID . ' not found.');
        }

        return view('customer_edit', ['customer' => $customer]);
    }
    public function update_customer($userID)
    {
        $model = new UserModel();
        $data = [
            'FirstName' => $this->request->getPost('FirstName'),
            'SecondName' => $this->request->getPost('SecondName'),
            'Phone' => $this->request->getPost('Phone'),
            'Email' => $this->request->getPost('Email')
        ];

        if ($model->update($userID, $data)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Customer updated successfully');
        } else {
            return redirect()->back()->with('error', 'Failed to update customer');
        }
    }
    public function delete_customer($userID)
    {
        $model = new UserModel();

        if ($model->delete($userID)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Customer deleted successfully.');
        } else {
            return redirect()->back()->with('error', 'Failed to delete customer.');
        }
    }

    // orders table
    public function edit_order($orderID)
    {
        $model = new OrdersModel(); 
        $order = $model->find($orderID);

        return view('order_edit', ['order' => $order]);
    }
    public function update_order($orderID)
    {
        $model = new OrdersModel();
        $data = [
            'ShopID' => $this->request->getPost('ShopID'),
            'TableID' => $this->request->getPost('TableID'),
            'OrderStatus' => $this->request->getPost('OrderStatus'),
        ];

        if ($model->update($orderID, $data)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Order updated successfully');
        } else {
            return redirect()->back()->with('errors', $model->errors())->with('message', 'Failed to update order');
        }
    }
    public function delete_order($orderID)
    {
        $model = new OrdersModel();

        if ($model->delete($orderID)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Order deleted successfully');
        } else {
            return redirect()->back()->with('message', 'Failed to delete order');
        }
    }

    // orderdetails table
    public function edit_orderdetail($orderDetailID)
    {
        $model = new OrderDetailsModel();
        $orderdetail = $model->find($orderDetailID);

        return view('orderdetail_edit', ['orderDetail' => $orderdetail]);
    }
    public function update_orderdetail($orderDetailID)
    {
        $model = new OrderDetailsModel();
        $data = [
            'OrderID' => $this->request->getPost('OrderID'),
            'MenuID' => $this->request->getPost('MenuID'),
            'Quantity' => $this->request->getPost('Quantity')
        ];

        if ($model->update($orderDetailID, $data)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Order detail updated successfully');
        } else {
            return redirect()->back()->with('errors', $model->errors())->withInput();
        }
    }
    public function delete_orderdetail($orderDetailID)
    {
        $model = new OrderDetailsModel();
        if ($model->delete($orderDetailID)) {
            return redirect()->to('/ManagementBoard')->with('message', 'Order detail deleted successfully');
        } else {
            return redirect()->back()->with('error', 'Failed to delete the order detail');
        }
    }
            






    

}
