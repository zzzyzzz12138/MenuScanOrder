<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class LoginController extends BaseController
{
    public function index()
    {
        return view('login');
    }

    public function authenticate()
    {
        $session = session();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $model = new UserModel();
        $user = $model->where('Email', $email)->first();

        if (!$user) {
            echo "No user found with that email";
            exit;
        }

        if ($user && password_verify($password, $user['Password'])) {
            $sessionData = [
                'UserID' => $user['UserID'],
                'FirstName' => $user['FirstName'],
                'Email' => $user['Email'],
                'UserType' => $user['UserType'],
                'isLoggedIn' => true
            ];
            $session->set($sessionData);

            if ($user['UserType'] == 'Customer') {
                return redirect()->to('/');
            } elseif ($user['UserType'] == 'Staff') {
                return redirect()->to('/ManagementBoard');
            }
        } else {
            $session->setFlashdata('error', 'Email or Password is incorrect');
            echo "Email or Password is incorrect";
            exit;
        }
    }

}
