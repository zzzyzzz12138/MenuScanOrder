<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\MenusModel;
use App\Models\ShopInformationModel;

class MenuController extends BaseController
{
    public function __construct()
    {
        // Load the URL helper, it will be useful in the next steps
        // Adding this within the __construct() function will make it 
        // available to all views in the ResumeController
        helper('url'); 
    }

    public function index()
    {
        return view('Menu');
    }

    public function view_menus()
    {
        $shopId = $this->request->getGet('shop_id');
        $tableId = $this->request->getGet('table_id'); // not use to display the menus

        $menuModel = new MenusModel();
        $shopModel = new ShopInformationModel();

        $shop = $shopModel->find($shopId);
        if (!$shop) {
            return redirect()->to('/ManagementBoard')->with('error', 'No shop found for the specified ID');
        }

        $data['shopName'] = $shop['ShopName'];
        $data['shopDescription'] = $shop['ShopDescription'];

        $data['mainCourses'] = $menuModel->where('ShopID', $shopId)
                                         ->where('Category', 'Main Course')
                                         ->findAll();
        $data['beverages'] = $menuModel->where('ShopID', $shopId)
                                        ->where('Category', 'Beverage')
                                        ->findAll();
        $data['snacks'] = $menuModel->where('ShopID', $shopId)
                                        ->where('Category', 'Snack')
                                        ->findAll();
        $data['desserts'] = $menuModel->where('ShopID', $shopId)
                                        ->where('Category', 'Dessert')
                                        ->findAll();


        return view('Menu', $data); 
    }

    public function submitOrder()
    {
        $shopId = $this->request->getGet('shop_id');
        $tableId = $this->request->getGet('table_id');

        if (!$shopId || !$tableId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Shop ID and Table ID are required']);
        }

        $jsonData = $this->request->getJSON(true);

        $ordersModel = new OrdersModel();
        $orderData = [
            'ShopID' => $shopId,
            'TableID' => $tableId,
            'OrderStatus' => 'preparing'
        ];
        $orderId = $ordersModel->insert($orderData);

        if (!$orderId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to create order']);
        }

        $orderDetailsModel = new OrderDetailsModel();
        if (isset($jsonData['orders'])) {
            foreach ($jsonData['orders'] as $item) {
                $orderDetails = [
                    'OrderID' => $orderId,
                    'MenuID' => $item['menuID'],
                    'Quantity' => $item['quantity']
                ];
                if (!$orderDetailsModel->insert($orderDetails)) {
                    return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to insert order details']);
                }
            }
        }

        return $this->response->setJSON(['status' => 'success', 'message' => 'Order successfully placed', 'orderId' => $orderId]);
    }


}