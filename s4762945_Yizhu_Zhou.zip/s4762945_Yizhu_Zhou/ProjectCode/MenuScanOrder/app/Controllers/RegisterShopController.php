<?php namespace App\Controllers;

use App\Models\ShopInformationModel;

class RegisterShopController extends BaseController
{
    public function index()
    {
        return view('register_shop');
    }

    public function registerShop()
    {
        $model = new ShopInformationModel();

        $data = [
            'ShopName' => $this->request->getPost('ShopName'),
            'ShopDescription' => $this->request->getPost('ShopDescription'),
        ];


        if ($model->save($data)) {
            return redirect()->to('/login')->with('message', 'Shop registered successfully');
        } else {
            log_message('error', 'Failed to save the shop: ' . print_r($model->errors(), true));
            return redirect()->back()->with('error', 'Failed to register shop');
        }
    }

}
