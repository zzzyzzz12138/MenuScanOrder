<?php 

namespace App\Controllers;

use App\Models\TablesModel;

class QRCodeController extends BaseController
{
    public function index()
    
    {
        $model = new TablesModel();
        $data['tables'] = $model->findAll();
        return view('QRcodeGeneration', $data);
    }

    public function edit($tableId)
    {
        $model = new TablesModel();
        $table = $model->find($tableId);

        if (!$table) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Table with ID ' . $tableId . ' not found.');
        }

        return view('table_edit', ['table' => $table]);
    }


    public function update($tableId)
    {
        $model = new TablesModel();
        
        $data = [
            'ShopID' => $this->request->getPost('ShopID'),
            'NumberOfSeats' => $this->request->getPost('NumberOfSeats'),
            'QRcodeURL' => $this->request->getPost('QRcodeURL'),
        ];

        log_message('info', 'Attempting to update table with ID: ' . $tableId . ' and data: ' . print_r($data, true));

        if ($model->update($tableId, $data)) {
            log_message('info', 'Update successful for Table ID: ' . $tableId);
            return redirect()->to('/QRcodeGeneration')->with('message', 'Table updated successfully');
        } else {
            log_message('error', 'Update failed for Table ID: ' . $tableId . ' Errors: ' . print_r($model->errors(), true));
            return redirect()->back()->with('errors', $model->errors())->with('message', 'Update failed');
        }
    }


    public function delete($tableId)
    {
        $model = new TablesModel();
        
        if ($model->delete($tableId)) {
            return redirect()->to('/QRcodeGeneration')->with('message', 'Table deleted successfully');
        } else {
            return redirect()->back()->with('message', 'Delete failed');
        }
    }

    public function add()
    {
        return view('table_add');
    }

    public function create()
    {
        $model = new TablesModel();

        
            $data = [
                'ShopID' => $this->request->getPost('ShopID'),
                'NumberOfSeats' => $this->request->getPost('NumberOfSeats'),
                'QRcodeURL' => $this->request->getPost('QRcodeURL'),
            ];

            if ($model->insert($data)) {
                return redirect()->to('/QRcodeGeneration')->with('message', 'New table added successfully');
            } else {
                return redirect()->back()->with('errors', $model->errors())->with('message', 'Failed to add new table');
            }
        

        return view('table_add');
    }

    
}
