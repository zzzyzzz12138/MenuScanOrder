<?php namespace App\Controllers;

use App\Models\UserModel;

class RegisterController extends BaseController
{
    public function index()
    {
        return view('register');
    }

    public function register()
    {
        //if ($this->request->getMethod() === 'post') {
            $model = new UserModel();

            $userData = [
                'FirstName' => $this->request->getPost('firstName'),
                'SecondName' => $this->request->getPost('secondName'),
                'Phone' => $this->request->getPost('phone'),
                'Email' => $this->request->getPost('email'),
                'Password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                'UserType' => $this->request->getPost('userType')
            ];

            $additionalData = [
                'ShopID' => $this->request->getPost('shopId'), 
                'Role' => $this->request->getPost('role'), 
                'Address' => $this->request->getPost('address'), 
                'Salary' => $this->request->getPost('salary')
            ];

            if ($model->registerUser($userData, $additionalData)) {
                return redirect()->to('/login');
            } else {
                return redirect()->back()->with('error', 'Registration failed');
            }

        //}
        return view('/login');
    }
}
