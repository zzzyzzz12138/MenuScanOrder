<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index'); <- Comment out the initial route


//Menu page
$routes->get('/', 'MenuController::index');
$routes->get('/view_menus', 'MenuController::view_menus');
$routes->post('/submit-order', 'MenuController::submitOrder');


//login page
$routes->get('/login', 'LoginController::index');
$routes->post('/login', 'LoginController::authenticate');

//register page
$routes->get('/register', 'RegisterController::index');
$routes->post('/register', 'RegisterController::register');

//register_shop page
$routes->get('/register_shop', 'RegisterShopController::index');
$routes->post('/register_shop', 'RegisterShopController::registerShop');


//management board page
$routes->get('/ManagementBoard', 'ManagementController::index');
$routes->get('/ManagementBoard/edit/(:num)', 'ManagementController::edit/$1');
$routes->post('/ManagementBoard/update/(:num)', 'ManagementController::update/$1');

$routes->get('ManagementBoard/edit_menus/(:num)', 'ManagementController::edit_menus/$1');// menus table
$routes->post('ManagementBoard/update_menus/(:num)', 'ManagementController::update_menus/$1');
$routes->get('ManagementBoard/delete_menus/(:num)', 'ManagementController::delete_menus/$1');
$routes->post('ManagementBoard/create_menus', 'ManagementController::create_menus');
$routes->get('/menu_add', 'ManagementController::menu_add');// for menu_add.php

$routes->get('ManagementBoard/edit_staff/(:num)', 'ManagementController::edit_staff/$1');// staffs table
$routes->post('ManagementBoard/update_staff/(:num)', 'ManagementController::update_staff/$1');
$routes->get('ManagementBoard/delete_staff/(:num)', 'ManagementController::delete_staff/$1');

$routes->get('ManagementBoard/edit_customer/(:num)', 'ManagementController::edit_customer/$1');// customers table
$routes->post('ManagementBoard/update_customer/(:num)', 'ManagementController::update_customer/$1');
$routes->get('ManagementBoard/delete_customer/(:num)', 'ManagementController::delete_customer/$1');

$routes->get('ManagementBoard/edit_order/(:num)', 'ManagementController::edit_order/$1');// orders table
$routes->post('ManagementBoard/update_order/(:num)', 'ManagementController::update_order/$1');
$routes->get('ManagementBoard/delete_order/(:num)', 'ManagementController::delete_order/$1');

$routes->get('ManagementBoard/edit_orderdetail/(:num)', 'ManagementController::edit_orderdetail/$1');// orderdetails table
$routes->post('ManagementBoard/update_orderdetail/(:num)', 'ManagementController::update_orderdetail/$1');
$routes->get('ManagementBoard/delete_orderdetail/(:num)', 'ManagementController::delete_orderdetail/$1');

//QR code generation page
$routes->get('/QRcodeGeneration', 'QRCodeController::index');
$routes->get('/QRcodeGeneration/edit/(:num)', 'QRCodeController::edit/$1');
$routes->post('/QRcodeGeneration/update/(:num)', 'QRCodeController::update/$1');
$routes->get('/QRcodeGeneration/delete/(:num)', 'QRCodeController::delete/$1');
$routes->get('/QRcodeGeneration/add', 'QRCodeController::add');// table_add.php
$routes->post('/QRcodeGeneration/create', 'QRCodeController::create');


