<?php

namespace App\Models;

use CodeIgniter\Model;

class ShopInformationModel extends Model
{
    protected $table = 'Shops'; // related table name
    protected $primaryKey = 'ShopID';

    protected $allowedFields = ['ShopName', 'ShopDescription']; // allow to change

    protected $returnType = 'array';
    protected $useTimestamps = false;


}
