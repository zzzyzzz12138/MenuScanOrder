<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'Users';
    protected $primaryKey = 'UserID';
    protected $allowedFields = ['FirstName', 'SecondName', 'Phone', 'Email', 'Password', 'UserType'];
    protected $returnType = 'array';
    protected $useTimestamps = false;

    
    public function registerUser($userData, $additionalData)
    {
        //$this->db->transStart();

        $this->insert($userData);
        $userId = $this->insertID();

        if ($userData['UserType'] == 'Staff') {
            $staffData = array_merge($additionalData, ['UserID' => $userId]);
            $this->db->table('Staffs')->insert($staffData);
        } elseif ($userData['UserType'] == 'Customer') {
            $customerData = ['UserID' => $userId];
            $this->db->table('Customers')->insert($customerData);
        }

        //$this->db->transComplete();

        return $this->db->transStatus();
    }

    public function getStaffDetails()
    {
        $builder = $this->db->table('Users');
        $builder->select('Users.UserID, Users.FirstName, Users.SecondName, Users.Phone, Users.Email, Staffs.ShopID, Staffs.Role, Staffs.Address, Staffs.Salary');
        $builder->join('Staffs', 'Staffs.UserID = Users.UserID');
        $builder->where('Users.UserType', 'Staff');
        //$builder->where('Users.UserID', $userID);
        return $builder->get()->getRowArray(); // Use getRowArray() instead of getResultArray() to return only one row

    }
    public function getAllStaffDetails()
    {
        $builder = $this->db->table('Users');
        $builder->select('Users.UserID, Users.FirstName, Users.SecondName, Users.Phone, Users.Email, Staffs.ShopID, Staffs.Role, Staffs.Address, Staffs.Salary');
        $builder->join('Staffs', 'Staffs.UserID = Users.UserID');
        $builder->where('Users.UserType', 'Staff');
        return $builder->get()->getResultArray(); 
    }
    public function updateStaff($userID, $userData, $staffData)
    {
        $this->db->transStart();

        $this->update($userID, $userData);

        $this->db->table('Staffs')->where('UserID', $userID)->update($staffData);

        $this->db->transComplete(); 

        return $this->db->transStatus();
    }

    public function getAllCustomerDetails()
        {
            $builder = $this->db->table('Users');
            $builder->select('Users.UserID, Users.FirstName, Users.SecondName, Users.Phone, Users.Email');
            $builder->join('Customers', 'Customers.UserID = Users.UserID');
            $builder->where('Users.UserType', 'Customer');
            return $builder->get()->getResultArray();
        }
    public function getCustomerDetails()
    {
        $builder = $this->db->table('Users');
        $builder->select('Users.UserID, Users.FirstName, Users.SecondName, Users.Phone, Users.Email');
        $builder->join('Customers', 'Customers.UserID = Users.UserID');
        $builder->where('Users.UserType', 'Customer');
        return $builder->get()->getRowArray();
    }
    public function updateCustomer($userID, $userData, $customerData)
    {
        $this->db->transStart();

        $this->update($userID, $userData);

        $this->db->table('Customers')->where('UserID', $userID)->update($customerData);

        $this->db->transComplete();

        return $this->db->transStatus();
    }

    







}
