<?php

namespace App\Models;

use CodeIgniter\Model;

class TablesModel extends Model
{
    protected $table = 'Tables';
    protected $primaryKey = 'TableID';

    protected $allowedFields = ['ShopID', 'NumberOfSeats', 'QRcodeURL'];

    protected $returnType = 'array'; 
    protected $useSoftDeletes = false; 

    protected $validationRules = []; 
    protected $validationMessages = []; 
    protected $skipValidation = false; 
}
