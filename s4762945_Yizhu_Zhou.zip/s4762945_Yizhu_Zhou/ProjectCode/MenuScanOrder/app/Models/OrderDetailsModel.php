<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderDetailsModel extends Model
{
    protected $table = 'OrderDetails';
    protected $primaryKey = 'OrderDetailID';
    protected $allowedFields = ['OrderID', 'MenuID', 'Quantity'];

    public function getAllOrderDetails()
    {
        return $this->findAll();
    }
}
