<?php

namespace App\Models;

use CodeIgniter\Model;

class MenusModel extends Model
{
    protected $table = 'Menus';
    protected $primaryKey = 'MenuID';

    // allow to change
    protected $allowedFields = [
        'ShopID',
        'Category',
        'ItemName',
        'MenuDescription',
        'Price',
        'AvailableQuantity',
        'ImagePath'
    ];
    
    protected $returnType = 'array';

    protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;
}
