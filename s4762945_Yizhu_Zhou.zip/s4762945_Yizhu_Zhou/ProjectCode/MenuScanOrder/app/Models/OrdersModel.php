<?php

namespace App\Models;

use CodeIgniter\Model;

class OrdersModel extends Model
{
    protected $table = 'Orders';
    protected $primaryKey = 'OrderID';
    protected $allowedFields = ['ShopID', 'TableID', 'OrderStatus'];

    public function getAllOrders()
    {
        return $this->findAll();
    }
}
